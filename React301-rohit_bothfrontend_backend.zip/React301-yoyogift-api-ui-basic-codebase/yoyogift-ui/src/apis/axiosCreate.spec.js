
import axiosMock from 'axios'


jest.mock('axios')

describe.only('fetchTradersApi', () => {
  
  it('Calls axios and returns traders', async () => {
    axiosMock.get.mockImplementationOnce(() =>
      Promise.resolve({
        data: ['Jo Smith'],
      })
    )
   
  })
})