import React from "react";
import ReactDOM from "react-dom";
import { ReactStrictMode, rootElement } from './index'
import App from "./modules/App";
import { createStore, applyMiddleware, compose} from "redux";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import reducers from "./store";
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
jest.mock("react-dom", () => ({ render: jest.fn() }));
const store = createStore(reducers, composeEnhancers(applyMiddleware(thunk)))
describe('index.js', () => {
    it("should render the app inside div which has root id", () => {
        expect(global.document.getElementById("root")).toBeDefined();
      });
      it("should render App component", () => {
        expect(App).toBeDefined();
      })
  })