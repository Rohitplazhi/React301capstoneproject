export const apiURL = 'http://localhost:10000'
export const adminEmail = [
    "yoyogiftg2@gmail.com",
    "erohitk@gmail.com"
]