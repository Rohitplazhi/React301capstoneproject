import  rootReducer  from './index';
import { createStore } from 'redux';


describe('Root Reducer Suite', () => {

  let store = createStore(rootReducer)

  it('loaded correctly', () => {
    expect(store.getState().users).toEqual({"UserDetails": [], "cards": []});
  });
  it('loaded correctly', () => {
    expect(store.getState().login).toEqual({  "detailsObject": {},
       "loginStatus": false});
  });
});