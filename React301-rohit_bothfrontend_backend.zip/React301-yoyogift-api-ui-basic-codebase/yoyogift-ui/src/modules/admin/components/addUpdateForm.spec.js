import React from "react";

import { mount, shallow, configure } from "enzyme";
import AddUpdateForm from "./addUpdateForm";
import Adapter from 'enzyme-adapter-react-16';
import {Button} from '@material-ui/core';
import { BrowserRouter as Router } from "react-router-dom"
import createMockStore from "redux-mock-store";
import thunk from "redux-thunk";

import { Provider } from "react-redux";
configure({adapter: new Adapter()});
const middlewares = [thunk];
 const mockStore = (state) => {

  const mockStore = createMockStore(middlewares);

  return mockStore(state);

};

let testInitialState = {

  gifts: {

    giftCards: [],

    giftCardsFiltered: [],

    giftCard: {},

  },

  login: {

    loginStatus: true,

    detailsObject: {
  

        "googleId": "107982366243618984531",
        "imageUrl": "https://lh3.googleusercontent.com/a/AATXAJxYWreanWH4ZKEq8UTeCKsUcpe36_n8PkTO-XCj=s96-c",
        "email": "erohitk@gmail.com",
        "name": "Rohit K",
        "givenName": "Rohit",
        "familyName": "K",
        "id": "107982366243618984531",
        "balance_points": 5000,

    },

  },

  users: {

    cards: [],

    UserDetails: [],

    totalCardsCount: 100,

  },

};


let mockDb ={
  "users": [
  
  
    {
 
        "googleId": "107982366243618984531",
        "imageUrl": "https://lh3.googleusercontent.com/a/AATXAJxYWreanWH4ZKEq8UTeCKsUcpe36_n8PkTO-XCj=s96-c",
        "email": "erohitk@gmail.com",
        "name": "Rohit K",
        "givenName": "Rohit",
        "familyName": "K",
        "id": "107982366243618984531",
        "balance_points": 5000,
    }
  ],

"giftCards": [
  {
    "id": 4,
    "cardName": "Food Card",
    "cardPoints": 324,
    "cardCategory": "Ecommerce",
    "cardRetailer": "Flipkartw",
    "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardExpiryDate": "2019-05-31",
    "cardCount": 14,
    "cardImage": "https://images.gyft.com/merchants/i-1466456891460_667_hd.png",
    "cardVendor": "flipkart",
    "cardShortDesc": "30% OFF",
    "cardLongDesc": "Amazon Gift Cards are the Perfect Gift, Every Time. Use the eBay Gift Card to shop from millions of items in Electronics, Toys, Motors, Fashion, Home & Garden, Art, Collectibles, Sporting Goods and everything in-between. eBay Gift Cards never expire and have no fees. Use it to shop now or wait for the deal of a lifetime.",
    "cardComments": [
      {
        "id": 4,
        "first_name": "Rohit",
        "last_name": "k",
        "email": "erohitk@gmail.com",
        "rating": 3,
        "comment": "testing",
        "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      },
      {
        "id": 5,
        "first_name": "Sebastian",
        "last_name": "Eschweiler",
        "email": "sebastian@mindtree.com",
        "rating": 4,
        "comment": "aaaaaaasssasssaaaaaaaaaaaaaaaaavvvvvvvvvvvv",
        "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      },
      {
        "comment": "testtt",
        "id": 6,
        "email": "erohitk@gmail.com",
        "commented_on": "2022-04-25T16:42:44.147Z",
        "first_name": "Rohit",
        "last_name": "K",
        "rating": 5
      }
    ]
  },
  {
    "id": 2,
    "cardName": "Food Panda",
    "cardPoints": 201,
    "cardCategory": "Food",
    "cardRetailer": "Food Panda",
    "cardIssueDate": "2019-05-25T08:13:13.581Z",
    "cardExpiryDate": "2019-05-30",
    "cardCount": 9,
    "cardImage": "https://images-platform.99static.com/6fYHYo_pmPCI9E9x7YGgHHVB7c8=/500x500/top/smart/99designs-contests-attachments/12/12934/attachment_12934835",
    "cardVendor": "food Panda",
    "cardShortDesc": "10% OFF",
    "cardLongDesc": "Foodpanda (stylized as foodpanda) is a German mobile food delivery marketplace[1] headquartered in Berlin, Germany, operating in 40 countries and territories [2]. The service allows users to select from local restaurants and place orders via its mobile applications as well as its websites. The company has partnered with over 27,095 restaurants in 193 cities and works with over 15,733 delivery riders. The firm was acquired by Delivery Hero in early December 2016.",
    "cardComments": [
      {
        "id": 2,
        "first_name": "Rohit",
        "last_name": "k",
        "email": "erohitk@gmail.com",
        "rating": 3,
        "comment": "Great gift card. Happy to gift!",
        "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      }
    ]
  },
  {
    "id": 1,
    "cardName": "Ebay Card",
    "cardPoints": 123,
    "cardCategory": "Ecommerce",
    "cardRetailer": "eBay",
    "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardExpiryDate": "Sun May 26 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardCount": 8,
    "cardImage": "https://images.gyft.com/merchants/i-188-1346844971201-60_hd.png",
    "cardVendor": "ebay",
    "cardShortDesc": "50% OFF",
    "cardLongDesc": "Amazon Gift Cards are the Perfect Gift, Every Time. Use the eBay Gift Card to shop from millions of items in Electronics, Toys, Motors, Fashion, Home & Garden, Art, Collectibles, Sporting Goods and everything in-between. eBay Gift Cards never expire and have no fees. Use it to shop now or wait for the deal of a lifetime.",
    "cardComments": [
      {
        "id": 1,
        "first_name": "Sebastian",
        "last_name": "Eschweiler",
        "email": "sebastian@mindtree.com",
        "rating": 4,
        "comment": "Great gift card. Happy to gift!",
        "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      },
      {
        "id": 3,
        "first_name": "Murphy",
        "last_name": "Dil",
        "email": "murphydil@mindtree.com",
        "rating": 3,
        "comment": "Woah! Instant discount.",
        "commented_on": "Sun Apr 20 2019 15:43:25 GMT+0530 (India Standard Time)"
      }
    ]
  },
  {
    "id": 5,
    "cardName": "Happy Flip",
    "cardPoints": 321,
    "cardCategory": "Ecommerce",
    "cardRetailer": "Flipkart",
    "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardExpiryDate": "Sun May 26 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardCount": 7,
    "cardImage": "http://www.adageindia.in/photo/47460433/Is-Flipkarts-New-Logo-Strong-Enough-To-Behold-Its-Brand-Identity.jpg?19122",
    "cardVendor": "flipkart",
    "cardShortDesc": "35% OFF",
    "cardLongDesc": "Flipkart Pvt Ltd. is an e-commerce company based in Bengaluru, India. Founded by Sachin Bansal and Binny Bansal in 2007, the company initially focused on book sales, before expanding into other product categories such as consumer electronics, fashion, and lifestyle products.  The service competes primarily with Amazon's Indian subsidiary, and the domestic rival Snapdeal. as of March 2017, Flipkart held a 39.5% market share of India's e-commerce industry.Flipkart is significantly dominant in the sale of apparel",
    "cardComments": [
      {
        "id": 1,
        "first_name": "John",
        "last_name": "Hall",
        "email": "john@gmail.com",
        "rating": 3,
        "comment": "Great gift card. Happy to gift!",
        "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      }
    ]
  },
  {
    "id": 6,
    "cardName": "Joy Card",
    "cardPoints": 456,
    "cardCategory": "Ecommerce",
    "cardRetailer": "eBay",
    "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardExpiryDate": "Sun May 26 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardCount": 3,
    "cardImage": "https://images.gyft.com/merchants/i-188-1346844971201-60_hd.png",
    "cardVendor": "eBay",
    "cardShortDesc": "25% OFF",
    "cardLongDesc": "ebay Gift Cards are the Perfect Gift, Every Time. Use the ebay Gift Card to shop from millions of items in Electronics, Toys, Motors, Fashion, Home & Garden, Art, Collectibles, Sporting Goods and everything in-between. eBay Gift Cards never expire and have no fees. Use it to shop now or wait for the deal of a lifetime.",
    "cardComments": [
      {
        "id": 1,
        "first_name": "John",
        "last_name": "Hall",
        "email": "john@gmail.com",
        "rating": 3,
        "comment": "Great gift card. Happy to gift!",
        "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      }
    ]
  },
  {
    "id": 7,
    "cardName": "Food Card",
    "cardPoints": 123,
    "cardCategory": "Ecommerce",
    "cardRetailer": "Amazon",
    "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardExpiryDate": "Sun May 26 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardCount": 7,
    "cardImage": "https://images.gyft.com/merchants/i-1466456891460_667_hd.png",
    "cardVendor": "amazon",
    "cardShortDesc": "10% OFF",
    "cardLongDesc": "Amazon Gift Cards are the Perfect Gift, Every Time. Use the eBay Gift Card to shop from millions of items in Electronics, Toys, Motors, Fashion, Home & Garden, Art, Collectibles, Sporting Goods and everything in-between. eBay Gift Cards never expire and have no fees. Use it to shop now or wait for the deal of a lifetime.",
    "cardComments": [
      {
        "id": 1,
        "first_name": "Sebastian",
        "last_name": "Eschweiler",
        "email": "sebastian@mindtree.com",
        "rating": 4,
        "comment": "Great gift card. Happy to gift!",
        "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      }
    ]
  }
]
}


const getWaraper = (store) => {

  return mount(

   <Provider store={store}>
 <Router>
      <AddUpdateForm

       

      />
</Router>
    </Provider>

  );

};

let wrapper;

beforeEach(() => {

  let state = testInitialState;

  state.gifts.giftCard = mockDb.giftCards[0];

  state.users.UserDetails = mockDb.users[0];

  state.login.loginStatus = true;

  wrapper = getWaraper(mockStore(state));
  console.log('wrapper',wrapper)

});

describe("Gift show container test cases", () => {

  it("Should validate props", () => {

    expect(wrapper.props().store.getState().gifts.giftCard).toEqual(

      mockDb.giftCards[0]

    );

    

  });




  it("Should return GiftShow components length 1", () => {

    expect(wrapper.find("div").length).toBe(33);

  });




  const mockCallBack = jest.fn();
  it('should show dialogue box', () => {

    const btn = wrapper.find('button').at(0)

    btn.simulate('click');
    expect(mockCallBack.mock.calls.length).toEqual(0);
  });


 

});