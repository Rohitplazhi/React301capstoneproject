import React, { Component } from 'react'
import InputTypeComponent from "../../common/components/inputTypeComponent"
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import TextField from '@material-ui/core/TextField';
import { adminAddCard, adminUpdateCard } from "../../gifts/state/actions/index"
import history from '../../common/components/history';
import {DateFormatter} from '../../common/components/DateFormatter';
import {Grid,Container,Typography,Button} from '@material-ui/core';

import Snackbar  from "../../common/components/Snackbar";
import { Formik  } from "formik";
import * as yup from "yup";

class addUpdateForm extends Component {
  constructor(props){
    super(props);
    const initialValues={
    cardName: '',
    cardPoints: '',
    cardCategory: '',
    cardRetailer: '',
    cardExpiryDate: '',
    cardCount: '',
    cardImage: '',
    cardVendor: '',
    cardShortDesc: '',
    cardLongDesc: '',
    showErrorSnackBar: false,
    showUpdateSnackBar: false,
    showSuccessSnackBar: false,
    }
    this.state={initialValues};
    this.validationSchema=yup.object().shape({
    cardName:yup.string().required("Required"),
    cardPoints:yup.number().required("Required"),
    cardCategory:yup.string().required("Required"),
    cardRetailer:yup.string().required("Required"),
    cardExpiryDate:yup.date().required("Required"),
    cardImage:yup.string().required("Required"),
    cardLongDesc:yup.string().required("Required"),
    cardVendor:yup.string().required("Required"),
    cardShortDesc:yup.string().required("Required"),
    cardCount:yup.number().required("Required")
    });
    }
    
    
    
    componentDidMount(){
    
    this.props.giftCards.forEach(card => {
    if (card.id === +this.props.match.params.id) {
    this.currentGiftCard = card
    this.setState({initialValues:{
    cardName: this.currentGiftCard.cardName,
    cardPoints: this.currentGiftCard.cardPoints,
    cardCategory: this.currentGiftCard.cardCategory,
    cardRetailer: this.currentGiftCard.cardRetailer,
    cardExpiryDate: DateFormatter(this.currentGiftCard.cardExpiryDate),
    cardCount: this.currentGiftCard.cardCount,
    cardImage: this.currentGiftCard.cardImage,
    cardVendor: this.currentGiftCard.cardVendor,
    cardShortDesc: this.currentGiftCard.cardShortDesc,
    cardLongDesc: this.currentGiftCard.cardLongDesc,
    }});
    }
    })
    }
    submitHandler=(values)=>{   
    if (this.props.match.params.id && Object.keys(values).length !== 0) {
    this.props.adminUpdateCard(this.currentGiftCard.id, values).then((response) => {
    this.setState({
    showUpdateSnackBar: true
    });
    setTimeout(() => {
    this.setState({
    showUpdateSnackBar: false
    });
    history.push('/giftCards');
    }, 2000);
    })
    }else{
    let cardObject = {...values,
    id: Math.floor((Math.random() * 100) + 1),
    cardIssueDate: new Date(),
    cardComments: []
    }
    this.props.adminAddCard(cardObject).then(() => {
    this.setState({
    showSuccessSnackBar: true
    });
    setTimeout(() => {
    this.setState({
    showSuccessSnackBar: false
    });
    history.push('/giftCards');
    }, 2000);
    })
    
    
  }
    }
    validateHandler=(props)=>{
    console.log(props);
    }
    resetFormHandler=(props)=>{
    props.resetForm();
    }
  render() {
    return (

        
      <Formik 

    
      
      initialValues={this.state.initialValues} validate={this.validateHandler} onSubmit={this.submitHandler}  initialTouched={{field:true}} validationSchema={this.validationSchema} enableReinitialize={true} >
      {(formik)=>{
      return <form onSubmit={formik.handleSubmit} onReset={formik.handleReset}>
      <Grid container spacing={2}>
      <Grid item xs={12}>
      {/* <Typography>
      Add or Update Form
      </Typography> */}
      </Grid>
      <Grid item xs={6}>
        
      <TextField  style = {{width:500}}   name="cardName"  value={formik.values.cardName}    onChange={formik.handleChange} label="Card Name" placeholder="Card Name" error={formik.touched.cardName && Boolean(formik.errors.cardName)}/>
      </Grid>
      <Grid item xs={6}>
      <TextField style = {{width:500}} name="cardPoints"  value={formik.values.cardPoints}   error={formik.touched.cardPoints && Boolean(formik.errors.cardPoints)}  onChange={formik.handleChange} label="Card Points" placeholder="Card Points" type="number"/>
      </Grid>
      <Grid item xs={6}>
      <TextField style = {{width:500}} name="cardCategory"  value={formik.values.cardCategory}   error={formik.touched.cardCategory && Boolean(formik.errors.cardCategory)}  onChange={formik.handleChange} label="Card Category" placeholder="Card Category"/>
      </Grid>
      <Grid item xs={6}>
      <TextField style = {{width:500}} name="cardRetailer"   value={formik.values.cardRetailer}  error={formik.touched.cardRetailer && Boolean(formik.errors.cardRetailer)}  onChange={formik.handleChange} label="Card Retailer" placeholder="Card Retailer"/>
      </Grid>
      <Grid item xs={6}>
      <TextField style = {{width:500}}  name="cardImage" value={formik.values.cardImage}    error={formik.touched.cardImage && Boolean(formik.errors.cardImage)}  onChange={formik.handleChange} label="Card Image" placeholder="Card Image"/>
      </Grid>
      <Grid item xs={6}>
      <TextField style = {{width:500}} name="cardExpiryDate" value={formik.values.cardExpiryDate}   error={formik.touched.cardExpiryDate && Boolean(formik.errors.cardExpiryDate)}    onChange={formik.handleChange}  type="date"/>
      </Grid>
      <Grid item xs={6}>
      <TextField style = {{width:500}}  name="cardVendor" value={formik.values.cardVendor}   error={formik.touched.cardVendor && Boolean(formik.errors.cardVendor)}    onChange={formik.handleChange} label="Card Vendor" placeholder="Card Vendor"/>
      </Grid>
      <Grid item xs={6}>
      <TextField style = {{width : 400}}  name="cardCount"   value={formik.values.cardCount}   error={formik.touched.cardCount && Boolean(formik.errors.cardCount)}    onChange={formik.handleChange}  label="Card Count" placeholder="Card Count" type="number"/>
      </Grid>
      <Grid item xs={6}>
      <TextField style = {{width:400}}  name="cardLongDesc"   value={formik.values.cardLongDesc}  error={formik.touched.cardLongDesc && Boolean(formik.errors.cardLongDesc)}  onChange={formik.handleChange}  label="Long Description" placeholder="Long Description"/>
      </Grid>
      <Grid item xs={6}>
      <TextField  style = {{width:400}} name="cardShortDesc" value={formik.values.cardShortDesc}  error={formik.touched.cardShortDesc && Boolean(formik.errors.cardShortDesc)}   onChange={formik.handleChange} label="Short Description" placeholder="Short Description"/>
      </Grid>
      <Grid item xs={12}>
        <br/>
        <br/>
      <Button variant="contained" style={{marginLeft:'10px'}} onClick={()=>this.resetFormHandler(formik)}>Reset</Button>
      <Button variant="contained" style={{marginLeft:'10px'}} color="primary" type="submit">{(this.props.match.params.id) ? 'UPDATE' : 'ADD'}</Button>
      
      </Grid>
      </Grid>
      
      
      
      
      </form>}}
      
      
      
      </Formik>
  
    )
  }
}

const mapStateToProps = (state) => {
  return {
    giftCards: state.gifts.giftCards
  }
}

export default connect(mapStateToProps, {adminAddCard, adminUpdateCard})(withRouter(addUpdateForm));
