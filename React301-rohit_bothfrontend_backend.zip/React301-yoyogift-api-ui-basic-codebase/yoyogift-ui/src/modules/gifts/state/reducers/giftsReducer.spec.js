
import giftsReducer from "./giftsReducer";
import { FETCH_CARDS, FETCH_CARD,ADD_COMMENT,FETCH_MORE_ROWS, DELETE_CARD,DELETE_COMMENT, FETCH_CARD_FILTER, UPDATE_CARD_COUNT, ADMIN_ADD_CARD, ADMIN_UPDATE_CARD } from "../actions/types";

describe ("loginReducers Default Tests", () => {
    
    it ("should be empty list", () => {
        expect(giftsReducer (undefined, {type:'NOT THERE'})).toEqual({
            giftCards: [],
  giftCardsFiltered: [],
  giftCard: {},
xTotalCount: 0,
        })
    })



    it ("should set fetch card", () => {
        const action = {type:FETCH_CARDS}
        
    
        
        expect(giftsReducer ({giftCards: undefined, xTotalCount: undefined},action )).toEqual({
            giftCards:undefined, xTotalCount: undefined
        })
    })

    
    it ("should set fetch card", () => {
        const action = {type:FETCH_CARD}
        
    
        
        expect(giftsReducer ({giftCard: undefined},action )).toEqual({
            giftCard:undefined
        })
    })

    it ("should delete comment", () => {
        const action = {type:DELETE_COMMENT}
        
    
        
        expect(giftsReducer ({giftCard:undefined},action )).toEqual({
            giftCard:undefined
        })
    })

    it ("should add comments", () => {
        const action = {type:ADD_COMMENT}
        
    
        expect(giftsReducer ({giftCard:undefined},action )).toEqual({
            giftCard:undefined
        })
    })

    it ("should delete comments", () => {
        const action = {type:DELETE_CARD}
        
    
        expect(giftsReducer ({giftCards:undefined,giftCardsFiltered: undefined },action )).toEqual({
            giftCards:undefined,giftCardsFiltered: undefined
        })
    })

    it ("should admin  comments", () => {
        const action = {type:ADMIN_ADD_CARD}
        
    
        expect(giftsReducer ({giftCards: undefined },action )).toEqual({
            giftCards: undefined
        })
    })

    it ("should admin  comments", () => {
        const action = {type:UPDATE_CARD_COUNT}
        
    
        expect(giftsReducer ({giftCard: undefined },action )).toEqual({
            giftCard: undefined
        })
    })
    it ("should admin  giftCardsFiltered", () => {
        const action = {type:FETCH_CARD_FILTER}
        
    
        expect(giftsReducer ({giftCardsFiltered: undefined },action )).toEqual({
            giftCardsFiltered: undefined
        })
    })
  
    it ("should admin  ADMIN_UPDATE_CARD", () => {
        const action = {type:ADMIN_UPDATE_CARD}
        
    
        expect(giftsReducer ({giftCards: undefined },action )).toEqual({
            giftCards: undefined
        })
    })
  
  
  
    
  
 
})