

import axios     from 'axios';
import  MockAdapter from "axios-mock-adapter";
import axiosWrapper from "../../../../apis/axiosCreate";
import { fetchcardThunk, searchCardThunk, editCommentThunk, deleteCommentsThunk,adminAddCardThunk,fetchMoreRowsThunk,postCommentsThunk, updateCardCountThunk } from "./";
import * as actions from "../actions";

 
// This sets the mock adapter on the default instance
var mock = new MockAdapter(axios);

var mockWrapper = new MockAdapter(axiosWrapper);


describe ("getCards mock test", () => {

  it("should get products", async () => {
 

    mockWrapper.onGet("/giftCards").reply(200, 
    [{ "cardName": "Food Card",
                      "cardPoints": 324,
                      "cardCategory": "Ecommerce"}]
);

const products =   await fetchcardThunk();
expect(products.data).toEqual([{ "cardName": "Food Card",
"cardPoints": 324,
"cardCategory": "Ecommerce"}])
 


})   
    it("should get products", async () => {
 

    mockWrapper.onGet("/giftCards").reply(200, 
    [{ "cardName": "Food Card",
                      "cardPoints": 324,
                      "cardCategory": "Ecommerce"}]
);

const products =   await fetchcardThunk();
expect(products.data).toEqual([{ "cardName": "Food Card",
"cardPoints": 324,
"cardCategory": "Ecommerce"}])
 


})    

it("should get products", async () => {
 
    
    mockWrapper.onGet(`/giftCards/${'food'}`).reply(200, 
    [{ "cardName": "Food Card",
                      "cardPoints": 324,
                      "cardCategory": "Ecommerce"}]
);

const products =   await searchCardThunk('food');
expect(products.data).toEqual([{ "cardName": "Food Card",
"cardPoints": 324,
"cardCategory": "Ecommerce"}])
 


}) 

it("should get products", async () => {
 
    
    mockWrapper.onGet(`/giftCards?q=zomato&_start=1&_end=2`).reply(200, 
      [
        {
          "id": 98,
          "cardName": "Zomato",
          "cardPoints": "109",
          "cardCategory": "Food",
          "cardRetailer": "Zomato",
          "cardIssueDate": "2019-05-25T07:26:27.712Z",
          "cardExpiryDate": "2019-06-14T00:00:00.000Z",
          "cardCount": "4",
          "cardImage": "http://dap.optiononemiami.com/Recuiting_6/gift.jpg",
          "cardVendor": "Zomato",
          "cardShortDesc": "40% OFF",
          "cardLongDesc": "Zomato. Zomato is an Indian restaurant search and discovery service founded in 2008 by Deepinder Goyal and Pankaj Chaddah. It currently operates in 24 countries. It provides information and reviews of restaurants, including images of menus where the restaurant does not have its own website and also online delivery.",
          "cardComments": []
        }
      ]
        
);
const sortObject= {  filterValue: "All",
search: "zomato",
sortByValue: "None",
sortOrder: true
}
const products = [
  {
    "id": 98,
    "cardName": "Zomato",
    "cardPoints": "109",
    "cardCategory": "Food",
    "cardRetailer": "Zomato",
    "cardIssueDate": "2019-05-25T07:26:27.712Z",
    "cardExpiryDate": "2019-06-14T00:00:00.000Z",
    "cardCount": "4",
    "cardImage": "http://dap.optiononemiami.com/Recuiting_6/gift.jpg",
    "cardVendor": "Zomato",
    "cardShortDesc": "40% OFF",
    "cardLongDesc": "Zomato. Zomato is an Indian restaurant search and discovery service founded in 2008 by Deepinder Goyal and Pankaj Chaddah. It currently operates in 24 countries. It provides information and reviews of restaurants, including images of menus where the restaurant does not have its own website and also online delivery.",
    "cardComments": []
  }
]
console.log('products', products)
expect(products).toEqual([
  {
    "id": 98,
    "cardName": "Zomato",
    "cardPoints": "109",
    "cardCategory": "Food",
    "cardRetailer": "Zomato",
    "cardIssueDate": "2019-05-25T07:26:27.712Z",
    "cardExpiryDate": "2019-06-14T00:00:00.000Z",
    "cardCount": "4",
    "cardImage": "http://dap.optiononemiami.com/Recuiting_6/gift.jpg",
    "cardVendor": "Zomato",
    "cardShortDesc": "40% OFF",
    "cardLongDesc": "Zomato. Zomato is an Indian restaurant search and discovery service founded in 2008 by Deepinder Goyal and Pankaj Chaddah. It currently operates in 24 countries. It provides information and reviews of restaurants, including images of menus where the restaurant does not have its own website and also online delivery.",
    "cardComments": []
  }
])
 


}) 





it("should patch products", async () => {
 
    
  mockWrapper.onPatch(`/giftCards/2`, { cardComments: 
      {
          "id": 2,
          "first_name": "Rohit",
          "last_name": "k",
          "email": "erohitk@gmail.com",
          "rating": 3,
          "comment": "Great gift card. Happy to gift!",
          "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
        }
    }).reply(200, 
  [ {
      "id": 2,
      "first_name": "Rohit",
      "last_name": "k",
      "email": "erohitk@gmail.com",
      "rating": 3,
      "comment": "Great gift card. Happy to gift!",
      "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
    }
  ]
);

const products =  await deleteCommentsThunk({
  "id": 2,
  "first_name": "Rohit",
  "last_name": "k",
  "email": "erohitk@gmail.com",
  "rating": 3,
  "comment": "Great gift card. Happy to gift!",
  "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
} ,2,2);

expect(products).toEqual([{
  "id": 2,
  "first_name": "Rohit",
  "last_name": "k",
  "email": "erohitk@gmail.com",
  "rating": 3,
  "comment": "Great gift card. Happy to gift!",
  "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
}])



}) 


it("should patch products", async () => {
 
    
  mockWrapper.onPatch(`/giftCards/2`, { cardComments: 
      {
          "id": 2,
          "first_name": "Rohit",
          "last_name": "k",
          "email": "erohitk@gmail.com",
          "rating": 3,
          "comment": "Great gift card. Happy to gift!",
          "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
        }
    }).reply(200, 
  [ {
      "id": 2,
      "first_name": "Rohit",
      "last_name": "k",
      "email": "erohitk@gmail.com",
      "rating": 3,
      "comment": "Great gift card. Happy to gift!",
      "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
    }
  ]
);

const products =  await editCommentThunk({
  "id": 2,
  "first_name": "Rohit",
  "last_name": "k",
  "email": "erohitk@gmail.com",
  "rating": 3,
  "comment": "Great gift card. Happy to gift!",
  "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
} ,2,2);

expect(products).toEqual([{
  "id": 2,
  "first_name": "Rohit",
  "last_name": "k",
  "email": "erohitk@gmail.com",
  "rating": 3,
  "comment": "Great gift card. Happy to gift!",
  "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
}])



}) 



it("should patch products", async () => {
 
    
  mockWrapper.onPatch(`/giftCards/2`, { cardComments: 
      {
          "id": 2,
          "first_name": "Rohit",
          "last_name": "k",
          "email": "erohitk@gmail.com",
          "rating": 3,
          "comment": "Great gift card. Happy to gift!",
          "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
        }
    }).reply(200, 
  [ {
      "id": 2,
      "first_name": "Rohit",
      "last_name": "k",
      "email": "erohitk@gmail.com",
      "rating": 3,
      "comment": "Great gift card. Happy to gift!",
      "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
    }
  ]
);

const products =  await postCommentsThunk({
  "id": 2,
  "first_name": "Rohit",
  "last_name": "k",
  "email": "erohitk@gmail.com",
  "rating": 3,
  "comment": "Great gift card. Happy to gift!",
  "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
} ,2);

expect(products).toEqual([{
  "id": 2,
  "first_name": "Rohit",
  "last_name": "k",
  "email": "erohitk@gmail.com",
  "rating": 3,
  "comment": "Great gift card. Happy to gift!",
  "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
}])



}) 





it("should patch products", async () => {
 
    
    mockWrapper.onPatch(`/giftCards/2`, { cardComments: 
        {
            "id": 2,
            "first_name": "Rohit",
            "last_name": "k",
            "email": "erohitk@gmail.com",
            "rating": 3,
            "comment": "Great gift card. Happy to gift!",
            "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
          }
      }).reply(200, 
    [ {
        "id": 2,
        "first_name": "Rohit",
        "last_name": "k",
        "email": "erohitk@gmail.com",
        "rating": 3,
        "comment": "Great gift card. Happy to gift!",
        "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      }
    ]
);

const products =  await postCommentsThunk({
    "id": 2,
    "first_name": "Rohit",
    "last_name": "k",
    "email": "erohitk@gmail.com",
    "rating": 3,
    "comment": "Great gift card. Happy to gift!",
    "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
  } ,2,2);

expect(products).toEqual([{
    "id": 2,
    "first_name": "Rohit",
    "last_name": "k",
    "email": "erohitk@gmail.com",
    "rating": 3,
    "comment": "Great gift card. Happy to gift!",
    "commented_on": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
  }])
 


}) 



it("should patch products", async () => {
 
    
    mockWrapper.onPatch(`/giftCards/2`, { cardCount: 9}).reply(200, 
    [ {
        "cardCount": 9,
      }
    ]
);

const products =  await updateCardCountThunk(2,9);

expect(products).toEqual([{
    "cardCount": 9,
  }])
 


}) 


})


it("should post products", async () => {
 
    
  mockWrapper.onPost(`/giftCards`, {   
    "id": 4,
    "cardName": "Food Card",
    "cardPoints": 324,
    "cardCategory": "Ecommerce",
    "cardRetailer": "Flipkartw",
    "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardExpiryDate": "2019-05-31",
    "cardCount": 14,
    "cardImage": "https://images.gyft.com/merchants/i-1466456891460_667_hd.png",
    "cardVendor": "flipkart",
    "cardShortDesc": "30% OFF",
    "cardLongDesc": "Amazon Gift Cards are the Perfect Gift, Every Time. Use the eBay Gift Card to shop from millions of items in Electronics, Toys, Motors, Fashion, Home & Garden, Art, Collectibles, Sporting Goods and everything in-between. eBay Gift Cards never expire and have no fees. Use it to shop now or wait for the deal of a lifetime.",
    "cardComments": [
  
    ]
  }
        
    ).reply(200, 
  [ {
    "id": 4,
    "cardName": "Food Card",
    "cardPoints": 324,
    "cardCategory": "Ecommerce",
    "cardRetailer": "Flipkartw",
    "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardExpiryDate": "2019-05-31",
    "cardCount": 14,
    "cardImage": "https://images.gyft.com/merchants/i-1466456891460_667_hd.png",
    "cardVendor": "flipkart",
    "cardShortDesc": "30% OFF",
    "cardLongDesc": "Amazon Gift Cards are the Perfect Gift, Every Time. Use the eBay Gift Card to shop from millions of items in Electronics, Toys, Motors, Fashion, Home & Garden, Art, Collectibles, Sporting Goods and everything in-between. eBay Gift Cards never expire and have no fees. Use it to shop now or wait for the deal of a lifetime.",
    "cardComments": [
  
    ]
    }
  ]
);

const products =  await adminAddCardThunk({
  "id": 4,
    "cardName": "Food Card",
    "cardPoints": 324,
    "cardCategory": "Ecommerce",
    "cardRetailer": "Flipkartw",
    "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
    "cardExpiryDate": "2019-05-31",
    "cardCount": 14,
    "cardImage": "https://images.gyft.com/merchants/i-1466456891460_667_hd.png",
    "cardVendor": "flipkart",
    "cardShortDesc": "30% OFF",
    "cardLongDesc": "Amazon Gift Cards are the Perfect Gift, Every Time. Use the eBay Gift Card to shop from millions of items in Electronics, Toys, Motors, Fashion, Home & Garden, Art, Collectibles, Sporting Goods and everything in-between. eBay Gift Cards never expire and have no fees. Use it to shop now or wait for the deal of a lifetime.",
    "cardComments": [
  
    ]});

expect(products).toEqual([ {"id": 4,
"cardName": "Food Card",
"cardPoints": 324,
"cardCategory": "Ecommerce",
"cardRetailer": "Flipkartw",
"cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
"cardExpiryDate": "2019-05-31",
"cardCount": 14,
"cardImage": "https://images.gyft.com/merchants/i-1466456891460_667_hd.png",
"cardVendor": "flipkart",
"cardShortDesc": "30% OFF",
"cardLongDesc": "Amazon Gift Cards are the Perfect Gift, Every Time. Use the eBay Gift Card to shop from millions of items in Electronics, Toys, Motors, Fashion, Home & Garden, Art, Collectibles, Sporting Goods and everything in-between. eBay Gift Cards never expire and have no fees. Use it to shop now or wait for the deal of a lifetime.",
"cardComments": [

]}])



}) 


