import { FETCH_CARDS,DELETE_COMMENT, ADD_COMMENT, FETCH_MORE_ROWS, FETCH_CARD, DELETE_CARD,FETCH_CARD_FILTER, ADMIN_ADD_CARD, UPDATE_CARD_COUNT, ADMIN_UPDATE_CARD } from './types';
import axiosWrapper from '../../../../apis/axiosCreate';


const getQueryString=(sortObject)=>{
    let queryString="";
    let {search,sortOrder,sortByValue, filterValue}=sortObject;
    if(search){
    queryString+=`q=${search}`;
    }
    if(filterValue!=="All"){
    queryString+=`&cardRetailer=${filterValue}`;
    }
    switch(sortByValue){
    case 'Points':
    queryString+=`&_sort=cardPoints`;
    break;
    case 'Count':
    queryString+=`&_sort=cardCount`;
    break;
    case 'Validity':
    queryString+=`&_sort=cardExpiryDate`;
    break;
    default:
    break;
    }
    queryString+=`&_order=${sortOrder?"asc":"desc"}`;
    return queryString;
    }
    
    
    
    export const fetchCards = (sortObject) => async (dispatch) => {
    const queryString=getQueryString(sortObject);
    const response = await axiosWrapper.get(`/giftCards?${queryString}&_start=0&_end=9`);
    dispatch ({
    type: FETCH_CARDS,
    payload: response
    })
    }


    export const fetchMoreRows=(sortObject,startIndex,stopIndex)=>async(dispatch)=>{
        console.log('sortObject', sortObject)
    const queryString=getQueryString(sortObject);
    const response=await axiosWrapper.get(`/giftCards?${queryString}&_start=${startIndex}&_end=${stopIndex}`);
    dispatch({
    type:FETCH_MORE_ROWS,
    payload:response
    })
    }



export async function fetchMoreRowsThunk(sortObject,startIndex,stopIndex) {
    const queryString=getQueryString(sortObject)
    return axiosWrapper.get(`/giftCards?${queryString}&_start=${startIndex}&_end=${stopIndex}`).then(response => response.data);;
    
}

export async function fetchcardThunk() {

        return  await axiosWrapper.get('/giftCards');
        
}
export async function searchCardThunk(paramString) {

    return  await axiosWrapper.get(`/giftCards/${paramString}`);
    
}
export async function editCommentThunk(newData,id, pageId ) {

    return  axiosWrapper.patch(`/giftCards/${pageId}`, { cardComments: newData}).then(response => response.data);
 
}
export async function updateCardCountThunk(cardId, cardCount ) {

    return  axiosWrapper.patch(`/giftCards/${cardId}`, { cardCount: cardCount}).then(response => response.data);
 
}

export async function postCommentsThunk(newData, pageId ) {

    return  axiosWrapper.patch(`/giftCards/${pageId}`, { cardComments: newData}).then(response => response.data);
 
}

export async function deleteCommentsThunk(newData,id, pageId ) {

    return  axiosWrapper.patch(`/giftCards/${pageId}`, { cardComments: newData}).then(response => response.data);
 
}

export async function adminAddCardThunk(object ) {

    return axiosWrapper.post('/giftCards', object).then(response => response.data);
 
}



export const searchCard = (paramString) => async (dispatch) => {
    console.log('paramString', paramString)
    const response = await axiosWrapper.get(`/giftCards/${paramString}`);    
    dispatch ({
        type: FETCH_CARDS,
        payload: response
    })
}


export const deleteCard = (id) => async (dispatch) => {
    const response = await axiosWrapper.delete(`/giftCards/${id}`);
    console.log('response',response)
    dispatch ({
        type: DELETE_CARD,
        payload: id
    })
}

export const fetchCard = (id) => async (dispatch) => {
    const response = await axiosWrapper.get(`/giftCards/${id}`);
    dispatch ({
        type: FETCH_CARD,
        payload: response
    })
}

export const adminUpdateCard = (id, object) => async (dispatch) => {
    console.log(id)
    console.log(object)
    const response = await axiosWrapper.patch(`/giftCards/${id}`, object);
    console.log(response)
    dispatch ({
        type: ADMIN_UPDATE_CARD,
        payload: response
    })
}

export const fetchCardFilter = (object) => async (dispatch) => {
    dispatch ({
        type: FETCH_CARD_FILTER,
        payload: object
    })
}

export const adminAddCard = (object) => async(dispatch) => {
    const response = await axiosWrapper.post('/giftCards', object);
    dispatch ({
        type: ADMIN_ADD_CARD,
        payload: response
    })
}

export const updateCardCount = (cardId, cardCount) => async(dispatch) => {
    const response = await axiosWrapper.patch(`/giftCards/${cardId}`, { cardCount: cardCount});
    dispatch ({
        type: UPDATE_CARD_COUNT,
        payload: response.data
    })
}


export const deleteComments = (newData,id, pageId ) => async (dispatch) => {

    const response = await axiosWrapper.patch(`/giftCards/${pageId}`, { cardComments: newData});
    console.log('response',response )
    dispatch ({
        type: DELETE_COMMENT,
        payload: response.data

    })
}


export const editComment = (newData,id, pageId ) => async (dispatch) => {

    const response = await axiosWrapper.patch(`/giftCards/${pageId}`, { cardComments: newData});
    console.log('response', response)
    dispatch ({
        type: DELETE_COMMENT,
        payload: response.data

    })
}



export const postComments = (newData, pageId ) => async (dispatch) => {

    const response = await axiosWrapper.patch(`/giftCards/${pageId}`, { cardComments: newData});
    console.log('response', response)
    dispatch ({
        type: ADD_COMMENT,
        payload: response.data

    })
}




