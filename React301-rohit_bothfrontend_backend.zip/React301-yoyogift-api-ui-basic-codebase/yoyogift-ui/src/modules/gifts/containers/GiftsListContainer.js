import React from "react";
//import PropTypes from "prop-types";
import { connect } from "react-redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import Button from "@material-ui/core/Button";
import {Input, FormControl} from "@material-ui/core";
import { fetchCards, fetchCard, fetchCardFilter, deleteCard, fetchMoreRows} from "../state/actions";
import history from "../../common/components/history";
import Select from "@material-ui/core/Select";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import AscendingButton from "@material-ui/icons/SwapVert";
import IconButton from "@material-ui/core/IconButton";
import DescendingButton from "@material-ui/icons/SwapVerticalCircle";
import Tooltip from "@material-ui/core/Tooltip";
import { adminEmail } from '../../../config/constants';
import Grid from '@material-ui/core/Grid';
import axiosWrapper from '../../../apis/axiosCreate';
import SearchIcon from '@material-ui/icons/Search';
import CloseIcon from '@material-ui/icons/Close';
import GiftsListVirtualized from '../components/GiftListVirtualized';
const sortCategoryArray = ["Points", "Count", "Validity"];
class GiftsListContainer extends React.Component {
constructor(props) {
super(props);
this.state = {
sortOrder: true,
sortByValue: "None",
filterValue: 'All',
search:""
};
}
componentDidMount() {
let sortObject={...this.state};
this.props.fetchCards(sortObject);
}
componentDidCatch(error, info) {
console.log(error);
}
handleChangePage = (event, page) => {
this.setState({ page });
};



handleChangeRowsPerPage = event => {
this.setState({ page: 0, rowsPerPage: event.target.value });
};



handleSortButtonClick = () => {
const e = {
target: {
value: this.state.sortByValue
}
}
//this.onChangeSort(e)
this.setState({ sortOrder: !this.state.sortOrder },()=>{
this.props.fetchCards({...this.state});
});
};
// handleClickCard = (id) => {
// this.props.fetchCard(id);
// }



// handleUpdateClick = (id) => {
// console.log("container id", id);
// history.push('/AddUpdateForm/' + id)
// }
handleDelete=(id)=>{
console.log("delete", this);
let sortObject={...this.state};
this.props.deleteCard(id).then(()=>{
this.props.fetchCards(sortObject);
}).catch((err)=>{
console.log(err);
});
}



handleSearch=(e)=>{
/*let newGiftCard=[];
this.props.giftCards.forEach(ele=>{
if(ele.cardName.toLowerCase().startsWith(e.target.value.toLowerCase())){
newGiftCard.push(ele);
}
});
this.props.fetchCardFilter(newGiftCard);*/
this.setState({search:e.target.value});
}



onSearchClick=()=>{
let sortObject={...this.state};
this.props.fetchCards(sortObject);
}



onCloseClick=()=>{
this.setState({search:""},()=>{
let sortObject={...this.state};
this.props.fetchCards(sortObject);
})
}



onChangeRetailer = e => {
this.setState({
filterValue: e.target.value
},()=>{
let sortObject={...this.state};
this.props.fetchCards(sortObject);
})
/*let newGiftCard = [];
if (selectedValue !== "All") {
//this.props.giftCards.forEach(element => {
if (element.cardRetailer === selectedValue) {
newGiftCard.push(element);
}
});//



axiosWrapper.get(`/giftcards?cardRetailer=${selectedValue}`).then(element => {
this.props.fetchCardFilter(element.data)
})
} else {
newGiftCard = this.props.giftCards;
}
this.props.fetchCardFilter(newGiftCard)*/
};



sortGiftCards=async(value, order)=>{
let response;
if(this.state.filterValue!=="All"){
response=await axiosWrapper.get(`/giftCards?cardRetailer=${this.state.filterValue}&_sort=${value}&_order=${order}`);
return response.data;
}
response=await axiosWrapper.get(`/giftCards?_sort=${value}&_order=${order}`);
return response.data;
}



onChangeSort = async(e) => {
const { sortOrder } = this.state;
const giftCards = this.state.filterValue === 'All' ? this.props.giftCards : this.props.giftCardsFiltered;
/*this.setState({
sortByValue: e.target.value,
sortOrder: !this.state.sortOrder
})
let newGiftCard = giftCards;
if (e.target.value !== "None") {
switch (e.target.value) {
case "Points":
newGiftCard = sortOrder
? giftCards.sort(comparePointsAsc)
: giftCards.sort(comparePointsDesc);
break;
case "Count":
newGiftCard = sortOrder
? giftCards.sort(compareCountAsc)
: giftCards.sort(compareCountDesc);
break;
case "Validity":
newGiftCard = sortOrder
? giftCards.sort(compareValidityAsc)
: giftCards.sort(compareValidityDesc);
break;
default:
}
}
this.props.fetchCardFilter(newGiftCard);*/
this.setState({
sortByValue: e.target.value,
},()=>{
let sortObject={...this.state};
console.log("inside change",this.state);
this.props.fetchCards(sortObject);
})
/*let newGiftCard=giftCards;
if (e.target.value !== "None") {
switch (e.target.value) {
case "Points":
newGiftCard = sortOrder
? await this.sortGiftCards("cardPoints", "asc")
: await this.sortGiftCards("cardPoints", "desc");
break;
case "Count":
newGiftCard = sortOrder
? await this.sortGiftCards("cardCount", "asc")
: await this.sortGiftCards("cardCount", "desc");
break;
case "Validity":
newGiftCard = sortOrder
? await this.sortGiftCards("cardExpiryDate", "asc")
: await this.sortGiftCards("cardExpiryDate", "desc");
break;
default:
}
}
this.props.fetchCardFilter(newGiftCard);*/

};



addUpdateForm = () => {
history.push("/AddUpdateForm");
};



render() {
if (this.props.giftCards && this.props.giftCards.length === 0) {
return (
<CircularProgress style={{ marginLeft: "50%", marginTop: "10%" }} />
);
}
let cardRetailerArray = [];
for (let i = 0; i < (this.props.giftCards && this.props.giftCards.length); i++) {
cardRetailerArray.push(this.props.giftCards[i].cardRetailer);
}
let uniqueCardRetailerArray = [...new Set(cardRetailerArray)];
return (
<React.Fragment>
{/* <select onChange={this.onChangeRetailer}>
<option value="All">All</option>
{
uniqueCardRetailerArray.map((option) => {
return(
<option value={option}>{option}</option>
)
})
}
</select> */}
<Grid container spacing={0}>
<Grid item xs={12} sm={3}>
<label style={{ marginLeft: "2%" }}>Filter by Retailer:</label>
<Select
style={{
marginLeft: "2%",
marginTop: "2%",
width: "100px",
height: "35px"
}}
native
onChange={this.onChangeRetailer}
input={<OutlinedInput labelWidth={0} name="kpiValue" />}
>
<option value="All">All</option>
{uniqueCardRetailerArray.map(option => {
return <option key={option} value={option}>{option}</option>;
})}
</Select>
</Grid>
<Grid item xs={12} sm={3}>
<label style={{ marginLeft: "2%" }}>Sort by:</label>
<Select
style={{
marginLeft: "2%",
marginTop: "2%",
marginRight: "2%",
width: "100px",
height: "35px"
}}
native
onChange={this.onChangeSort}
input={<OutlinedInput labelWidth={0} name="sortByValue" />}
>
<option value="None">None</option>
{sortCategoryArray.map(option => {
return <option key={option} value={option}>{option}</option>;
})}
</Select>
{this.state.sortOrder ? (
<Tooltip
title={
this.state.sortByValue === "Validity"
? "Oldest to Newest"
: "Low to High"
}
>
<IconButton
onClick={this.handleSortButtonClick}
disabled={this.state.sortByValue === 'None'}>
<AscendingButton />
</IconButton>
</Tooltip>
) : (
<Tooltip
title={
this.state.sortByValue === "Validity"
? "Newest to Oldest"
: "High to Low"
}
>
<IconButton onClick={this.handleSortButtonClick}>
<DescendingButton />
</IconButton>
</Tooltip>
)}
</Grid>
<Grid item xs={12} sm={3}>
<FormControl style={{marginTop:"5px"}}>
<Input
type="text"
id="search"
placeholder={"search"}
onChange={this.handleSearch}
value={this.state.search}
/>
</FormControl>
<IconButton onClick={this.onSearchClick}>
<SearchIcon/>
</IconButton>
<IconButton onClick={this.onCloseClick}>
<CloseIcon/>
</IconButton>
</Grid>
<Grid item xs={12} sm={3}>
{adminEmail.includes(this.props.userDetails && this.props.userDetails.email) ? (
<Button
style={{ marginTop: "2%", marginRight: "3%", marginLeft: "2%" }}
variant="contained"
color="primary"
onClick={this.addUpdateForm}
>
ADD CARD
</Button>
) : null}
</Grid>
{/* <Grid item xs={12} sm={3}>
search bar:<input name="SearchBar" />
</Grid> */}
</Grid>

<div style={{ textAlign: 'center' }}>
<GiftsListVirtualized
{...this.props}
handleClickCard={this.handleClickCard}
handleUpdateClick={this.handleUpdateClick}
handleDelete={this.handleDelete}
sortObject={{...this.state}}

/>
</div>

</React.Fragment>
);
}
}



const mapStateToProps = state => {
return {
giftCards: state.gifts && state.gifts.giftCards,
giftCardsFiltered: state.gifts && state.gifts.giftCardsFiltered,
userDetails: state.login && state.login.detailsObject,
remoteRowCount:state.gifts.xTotalCount
};
};



/*GiftsListContainer.propTypes = {
classes: PropTypes.object.isRequired
};*/



export default connect(
mapStateToProps,
{ fetchCards, fetchCard, fetchCardFilter, deleteCard , fetchMoreRows}
)(GiftsListContainer);