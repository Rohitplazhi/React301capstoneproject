import React from "react";
import Adapter from 'enzyme-adapter-react-16';
import { Input, Button } from "@material-ui/core";
import SendGiftCardDialog from "../../common/components/DraggableDialog";
import { render, mount,shallow } from 'enzyme';
import { BrowserRouter as Router } from "react-router-dom"
import EditIcon from "@material-ui/icons/BorderColor";
import StarRatingComponent from "react-star-rating-component";
import GiftShow from "./GiftShow";
import { configure } from 'enzyme';
import { Provider } from "react-redux";
import configureMockStore from "redux-mock-store";
const mockStore = configureMockStore();
const store = mockStore({});
configure({adapter: new Adapter()});
describe("GiftShow component Suite", ()=> {
  const mockCallBack = jest.fn();
  const container = mount(<GiftShow  onClick={mockCallBack}/>);
  const wrapper = mount(<GiftShow />);
 
    it('should have  img field', () => {
        expect(container.find('img').length).toEqual(1);
      
      }); 
      it('should have  div field', () => {
        expect(container.find('div').length).toEqual(13);
      
      }); 

      it('should StarRatingComponent button field', () => {
        expect(container.find(StarRatingComponent).length).toEqual(1);
      
      }); 
      it('should input button field', () => {
        expect(container.find('input').length).toEqual(6);
      
      }); 

      it('should pass', () => {
    
        const wraper = wrapper.find(SendGiftCardDialog);
        expect(wrapper.find(SendGiftCardDialog).simulate('click'));
        wraper.update();
        expect(wrapper.find(SendGiftCardDialog).text()).toEqual('send this gift card');

      });

 

  
      
})