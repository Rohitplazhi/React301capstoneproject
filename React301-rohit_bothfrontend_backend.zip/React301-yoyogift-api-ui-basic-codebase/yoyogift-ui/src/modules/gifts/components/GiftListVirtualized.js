import React from 'react';
import {Grid,Container,TableCell,TableRow} from '@material-ui/core';
import { AutoSizer, InfiniteLoader ,Table} from 'react-virtualized';
import GiftCard from '../../common/components/GiftCard';

class GiftListVirtualized extends React.Component{
constructor(props){
super(props);
const matrixData=this.convertToMatrix(this.props.giftCards);
console.log(matrixData,props);
this.state={
giftCards:matrixData,
sortObject:this.props.sortObject,
headerHeight: 30,
height: 400,
hideIndexRow: false,
overscanRowCount: 40,
rowHeight: 400,
rowCount: matrixData.length,
useDynamicRowHeight: false,
remoteRowCount:Number(this.props.remoteRowCount)
}
}

componentDidUpdate(prevProps){
if(prevProps.giftCards!==this.props.giftCards){
const matrixData= this.convertToMatrix(this.props.giftCards);
this.setState({giftCards:matrixData,rowCount:matrixData.length});
}else if(prevProps.sortObject!==this.props.sortObject){
this.setState({sortObject:this.props.sortObject});
}
}



convertToMatrix=(giftCards, noOfCardsInRow=4)=>{
let matrix=[];
let lengthGift = giftCards && giftCards.length;
for(let i=0, k=-1; i<lengthGift; i++){
if(i%noOfCardsInRow==0){
k++;
matrix[k]=[];
}
matrix[k].push(giftCards[i]);
}
return matrix;
}



_noRowsRenderer() {
return <div >No rows</div>;
}



isRowLoaded =({ index })=> {
return !!this.state.giftCards[index];
}



loadMoreRows=({startIndex,stopIndex})=>{
if(startIndex*4>this.state.remoteRowCount){
return;
}
this.props.fetchMoreRows(this.props.sortObject,startIndex,stopIndex);
}



rowRenderer=({index,key,style})=>{
return (
<TableRow key={key} style={style}>
{this.state.giftCards[index].map((giftCard)=>{
return <TableCell>
<GiftCard giftCard={giftCard} userEmail={(this.props.userDetails && this.props.userDetails.email)} handleDelete={this.props.handleDelete}/>
</TableCell>
})}
</TableRow>
)
}

deleteCard =(id)=>{
    this.props.deleteCard(id)
  }

render(){
  console.log('this.state.giftCards', this.state.giftCards)
return(
<Grid>
<Container>
<AutoSizer style={{height:"300vh"}}>
{({height,width})=>(
<InfiniteLoader
isRowLoaded={this.isRowLoaded}
loadMoreRows={this.loadMoreRows}
rowCount={this.state.remoteRowCount}
>
{({onRowsRendered, registerChild})=>(
<Table
onRowsRendered={onRowsRendered}
ref={registerChild}
height={height}
width={width}
rowRenderer={this.rowRenderer}
rowGetter={({index})=>this.state.giftCards[index]}
rowCount={this.state.rowCount}
rowHeight={this.state.rowHeight}
noRowsRenderer={this._noRowsRenderer}
disableHeader
/>
)}
</InfiniteLoader>
)}
</AutoSizer>
</Container>
</Grid>
)
}
}



export default GiftListVirtualized;