import React from "react";
import Styles from "../../../assets/css/GiftShow.module.css";
import Grid from "@material-ui/core/Grid";
import { DateFormatter } from "./../../common/components/DateFormatter";
import StarRatingComponent from "react-star-rating-component";
import EditIcon from "@material-ui/icons/BorderColor";
import IconButton from "@material-ui/core/IconButton";
import Deleteicon from "@material-ui/icons/DeleteOutline";
import SendGiftCardDialog from "../../common/components/DraggableDialog";

const GiftShow = props => {
  const { data, user } = props;
  const [rating, setRating] = React.useState(0);
  const [editrating, setEditratingRating] =  React.useState("");
  const [editposition, setEditposition] = React.useState(0);
  const [editComment, seteditComment] = React.useState('false');
  const [commentType, setCommentType]= React.useState('');
  const [handleEditText, setHandleEditText]= React.useState('');
  const onStarClick=(nextValue, prevValue, name)=> {
    console.log('prevValue', prevValue)
    console.log('nextValue', nextValue)
    setRating(nextValue);
  }
  const onStarClickEdit=(nextValue, prevValue, name)=> {
    console.log('prevValue', prevValue)
    console.log('nextValue', nextValue)
    setEditratingRating(nextValue);
  }
  const handleTextComment = (e)=>{
    setCommentType(e.target.value);
  }

  const handleClose =()=>{
    seteditComment('false');
  }
const handleSubmit = (comment, user)=>{

  const findIndexs= comment.cardComments.map((obj => obj.id ));
  console.log('findIndexs', findIndexs.lastItem)
let newData = comment.cardComments.push({comment: commentType,
id:  Date.now().toString(36) + Math.random().toString(36).substr(2) ,
email: user.email,
commented_on: new Date(),
first_name: user.givenName,
last_name: user.familyName,
rating: rating })
console.log('newData', comment)

  props.postComments(comment,comment.id )
}


const handleEdit =(index)=>{
  setEditposition(index)
  seteditComment('true');
}


const handleDelete =(comment,id,pageNumber)=>{

  let newData = comment && comment.filter(res=> res.id !== id);


  props.deleteComments(newData, id, pageNumber )

}

const handleEditSubmit =async (comment,id,pageNumber,rating)=>{
  console.log('pageNumber', pageNumber)
  const findIndexs= comment.findIndex((obj => obj.id === id ));
    comment[findIndexs].rating =  rating 
  comment[findIndexs].comment = handleEditText || comment[findIndexs].comment;
  console.log('comment', comment)
  console.log('rating', rating)
  const result = await props.editComment(comment, id, pageNumber, rating );
  console.log('result', result)
}

console.log('editComment', editComment)


  return (
    <div style={{ padding: "4%" }}>
      <div className={Styles.detailsPage}>
        <Grid container spacing={0}>
          <Grid item xs={12} sm={5} className={Styles.cardContainer}>
            <div>
              <Grid container spacing={0}>
                <Grid item xs={6} sm={6}>
                  <img
                    src={data && data.cardImage}
                    alt="vendorImage"
                    className={Styles.vendorImage}
                  />
                </Grid>
                <Grid item xs={6} sm={6}>
                  <p className={Styles.cardName}>{data && data.cardName}</p>
                  <span style={{marginLeft:'30%'}}><label className={Styles.label}>Points:</label>{data && data.cardPoints}</span> 
                </Grid>
              </Grid>
            </div>
            <SendGiftCardDialog getEmail={(email) => {props.getEmail(email)}}/>
            <p><label className={Styles.label}>NUMBER OF CARDS AVAILABLE: </label>{data && data.cardCount}</p>
            <p><label className={Styles.label}>EXPIRY DATE: </label>{DateFormatter(data && data.cardExpiryDate)}</p>
            <div>
              <p className={Styles.label}> RATING & REVIEWS:</p>
              {
                data && data.cardComments ? 
                data && data.cardComments.map((comment,index) => {
                return (
                  
                  <div className={Styles.commentsSection}>
                    {  user.givenName === comment.first_name &&
                    <>
                    <IconButton>
                <Deleteicon onClick={()=>handleDelete(data && data.cardComments, comment.id,data && data.id)}/>
                </IconButton>
                <IconButton>
                <EditIcon onClick={()=> handleEdit(index)}/>
                </IconButton>
                </>
                } 
                    <p  className={Styles.commentorName}> {comment.first_name} {comment.last_name}<span className={Styles.commentDate}>{DateFormatter(comment.commented_on)}</span></p>
                    <p  onInput={(e) => setHandleEditText(e.currentTarget.textContent)} contenteditable={editComment} className={Styles.comment}>{comment.comment}</p>
                 
                    {(editComment === 'true' &&  editposition === index) ? <StarRatingComponent
                        name="rating"
                        starCount={5}
                        value={editposition === index ? editrating : comment.rating}
                        onStarClick={onStarClickEdit}
                        editing={editComment}
                      /> :
                      <StarRatingComponent
                        name="rating"
                        starCount={5}
                        value={comment.rating}
                        editing={editComment}
                      />}
                      { editComment === 'true' &&  editposition === index && <input type="button" value="update"  onClick = { ()=>handleEditSubmit(data.cardComments, comment.id,data.id,(comment.rating === editrating || editrating === 0 ? comment.rating : editrating)) } />}
                      { editComment === 'true' &&  editposition === index && <input type="button" value="close"  onClick = { ()=>handleClose() } />}
                  </div>
                )
              })
            :  <div>Loading User Reviews..</div>}
               <p>Add new comment</p>
            <textarea id="w3review" name="w3review" rows="4" cols="50" onChange = {handleTextComment}>

</textarea><br/>
                 <StarRatingComponent
                        name="rating"
                        starCount={5}
                        value={rating}
                        onStarClick={onStarClick}
                        editing={true}
                      />
                      <input type = {'submit'} onClick = { ()=>handleSubmit(data,user) } />
            </div>
          </Grid>
          <Grid item xs={12} sm={6} className={Styles.detailsContainer}>
            <p className={Styles.vendorName}>{data && data.cardVendor}</p>
            <p className={Styles.cardDescription}>{data && data.cardLongDesc}</p>
            {/* <p className={Styles.cardDescription}>Named “America’s Healthiest Grocery Store” by Health Magazine, Whole Foods Market is the leading organic and natural food retailer, prioritizing animal welfare, seafood sustainability, organic agriculture, and safer personal and home care products. Whole Foods Market strives to provide customers with a superiorcustomer service experience, while also supporting local producers, bettering the communities in which it operates, and improving the environment. Because of its dedication to strict quality standards and excellence, Whole Foods Market is able to offer its corporate and individual customers alike a consistently exceptional shopping experience. Whole Foods Market customers shop for quality and consistency, and are very loyal to the brands they like, patronizing the same stores again and again. Less focused on the bargain, Whole Foods Market customers have expendable income and care about where they spend their money, even going out of their way to shop at preferred retailers. Gift cards never expire and can buy anything at any of our 400 stores in the US and Canada. For more information on where to find the closest store</p> */}
          </Grid>
        </Grid>
      </div>
    </div>
  );
};
export default GiftShow;
