import React from "react";
import Adapter from 'enzyme-adapter-react-16';
import {Grid} from '@material-ui/core';
import { AutoSizer, InfiniteLoader ,Table} from 'react-virtualized';
import { render, mount, shallow } from 'enzyme';
import { BrowserRouter as Router } from "react-router-dom"
import GiftListVirtualized from "./GiftListVirtualized";
import { configure } from 'enzyme';
import { Provider } from "react-redux";
import configureMockStore from "redux-mock-store";
import { Input, Button } from "@material-ui/core";
const mockStore = configureMockStore();
const store = mockStore({});
configure({adapter: new Adapter()});

    
    const shallowComponent = (props = {}) => {

        return mount(<GiftListVirtualized {...props} />);
      
      };
      
      describe("Add Comment test cases", () => {
      
        let container;
      
        beforeEach(() => {
      
            container = shallowComponent();
      
        });
    it('should have  img field', () => {
        let wraper = container.find(AutoSizer)
        expect(wraper.length).toEqual(1);
      
      }); 
      it('should have  infiniteloader field', () => {
        let wraper = container.find(InfiniteLoader)
        expect(wraper.length).toEqual(1);
      
      }); 
      it('should have  Table field', () => {
        let wraper = container.find(Table)
        expect(wraper.length).toEqual(1);
      
      }); 
      
      

  
  


      it('Table properties', () => {
    
          expect(container.find(Table)).toHaveLength(1);
          expect(container.find(Table).prop('rowHeight')).toBe(400);
     
      });
     
  

      
})