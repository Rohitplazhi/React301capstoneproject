
import usersReducer from "./usersReducer";
import { RECEIVED_CARDS, SENT_CARDS, USER_DETAILS, REDEEM_CARD, UPDATE_BALANCE, UPDATE_TRANSACT } from "../actions/types";

describe ("loginReducers Default Tests", () => {
    
    it ("should be empty list", () => {
        expect(usersReducer (undefined, {type:'NOT THERE'})).toEqual({
            cards: [],
            UserDetails: []
        })
    })
    it ("should  receive card", () => {
        const action = {type:RECEIVED_CARDS}
        
    
        
        expect(usersReducer ({cards: undefined},action )).toEqual({
            cards:undefined
        })
    })


    it ("should sent comment", () => {
        const action = {type:SENT_CARDS}
        
    
        
        expect(usersReducer ({cards:undefined},action )).toEqual({
            cards:undefined
        })
    })

    it ("should user details", () => {
        const action = {type:USER_DETAILS}
        
    
        expect(usersReducer ({UserDetails:undefined},action )).toEqual({
            UserDetails:undefined
        })
    })

    it ("should update balance", () => {
        const action = {type:UPDATE_BALANCE}
        
    
        expect(usersReducer ({UserDetails:undefined},action )).toEqual({
            UserDetails:undefined
        })
    })

    it ("should user details", () => {
        const action = {type:REDEEM_CARD}
        
    
        expect(usersReducer ({cards:undefined},action )).toEqual({
            cards:undefined
        })
    })



    it ("should user details", () => {
        const action = {type:UPDATE_TRANSACT}
        
    
        expect(usersReducer ({cards:undefined},action )).toEqual({
            cards:undefined
        })
    })


  
  
 
})