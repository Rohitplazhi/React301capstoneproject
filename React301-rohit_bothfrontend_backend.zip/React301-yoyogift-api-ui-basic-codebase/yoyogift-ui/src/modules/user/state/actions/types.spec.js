


import React from "react";
import Adapter from 'enzyme-adapter-react-16';


import { render, mount, shallow } from 'enzyme';
import { BrowserRouter as Router } from "react-router-dom"
import types from "./types";
import { configure } from 'enzyme';
import { Provider } from "react-redux";
import configureMockStore from "redux-mock-store";
const mockStore = configureMockStore();
const store = mockStore({});
configure({adapter: new Adapter()});
describe('test MyComponent', () => {
    it('should disable submit button on submit click', () => {
        const wrapper = shallow(<types />);
  
      });
   
});