

import axios     from 'axios';
import  MockAdapter from "axios-mock-adapter";
import axiosWrapper from "../../../../apis/axiosCreate";
import { fetchReceivedCardsDispatch, fetchSentCardsDispatch, userDetailsDispatch,updateTransactDispatch, updateUserBalanceDispatch} from "./";

 
// This sets the mock adapter on the default instance
var mock = new MockAdapter(axios);

var mockWrapper = new MockAdapter(axiosWrapper);


describe ("getUsers mock test", () => {

    
it("should receive email", async () => {
 
    
    mockWrapper.onGet(`http://localhost:10000/giftTransact?receiverEmail=${'erohitk@gmail.com'}&_start=0&_end=10`).reply(200, 
    [{ "cardName": "Food Card",
                      "cardPoints": 324,
                      "cardCategory": "Ecommerce"}]
);

const products =   await fetchReceivedCardsDispatch('erohitk@gmail.com');
expect(products).toEqual([{ "cardName": "Food Card",
"cardPoints": 324,
"cardCategory": "Ecommerce"}])
 


}) 

it("should get email", async () => {
 
    
    mockWrapper.onGet(`http://localhost:10000/giftTransact?senderEmail=${'erohitk@gmail.com'}&_start=0&_end=10`).reply(200, 
    [{ "cardName": "Food Card",
                      "cardPoints": 324,
                      "cardCategory": "Ecommerce"}]
);

const products =   await fetchSentCardsDispatch('erohitk@gmail.com');
expect(products).toEqual([{ "cardName": "Food Card",
"cardPoints": 324,
"cardCategory": "Ecommerce"}])
 


}) 

it("should get email", async () => {
 
    
    mockWrapper.onGet("/users/107982366243618984531").reply(200, 
        [{ "googleId": "107982366243618984531",
        "imageUrl": "https://lh3.googleusercontent.com/a/AATXAJxYWreanWH4ZKEq8UTeCKsUcpe36_n8PkTO-XCj=s96-c",
        "email": "erohitk@gmail.com",
        "name": "Rohit K",
        "givenName": "Rohit",
        "familyName": "K",
        "id": "107982366243618984531",
        "balance_points": 4421}]
   );


const products =   await userDetailsDispatch('107982366243618984531');


expect(products).toEqual([{ "googleId": "107982366243618984531",
"imageUrl": "https://lh3.googleusercontent.com/a/AATXAJxYWreanWH4ZKEq8UTeCKsUcpe36_n8PkTO-XCj=s96-c",
"email": "erohitk@gmail.com",
"name": "Rohit K",
"givenName": "Rohit",
"familyName": "K",
"id": "107982366243618984531",
"balance_points": 4421}])
 


}) 

it("should get email", async () => {
 
    
    mockWrapper.onPatch("/users/107982366243618984531", {balance_points: 200}).reply(200, 
        [{ 
        "balance_points": 200}]
   );


const products =   await updateUserBalanceDispatch('107982366243618984531',200);


expect(products).toEqual([{  "balance_points": 200}])
 


})

it("should get email", async () => {
 
    
    mockWrapper.onPost("/giftTransact",     {
        "id": 8,
        "senderEmail": "lathak95@gmail.com",
        "receiverEmail": "soumodips90@gmail.com",
        "cardName": "Yoyo10",
        "cardPoints": 123,
        "cardShortDesc": "10% OFF",
        "cardImage": "https://images.gyft.com/merchants/i-1466456891460_667_hd.png",
        "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
        "cardExpiryDate": "Sun May 26 2019 15:43:25 GMT+0530 (India Standard Time)",
        "isRedeemed": false
      }).reply(200, 
        [    {
            "id": 8,
            "senderEmail": "lathak95@gmail.com",
            "receiverEmail": "soumodips90@gmail.com",
            "cardName": "Yoyo10",
            "cardPoints": 123,
            "cardShortDesc": "10% OFF",
            "cardImage": "https://images.gyft.com/merchants/i-1466456891460_667_hd.png",
            "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
            "cardExpiryDate": "Sun May 26 2019 15:43:25 GMT+0530 (India Standard Time)",
            "isRedeemed": false
          },]
   );
const products =   await updateTransactDispatch({    "id": 8,
"senderEmail": "lathak95@gmail.com",
"receiverEmail": "soumodips90@gmail.com",
"cardName": "Yoyo10",
"cardPoints": 123,
"cardShortDesc": "10% OFF",
"cardImage": "https://images.gyft.com/merchants/i-1466456891460_667_hd.png",
"cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
"cardExpiryDate": "Sun May 26 2019 15:43:25 GMT+0530 (India Standard Time)",
"isRedeemed": false});


expect(products).toEqual([{   "id": 8,
      "senderEmail": "lathak95@gmail.com",
      "receiverEmail": "soumodips90@gmail.com",
      "cardName": "Yoyo10",
      "cardPoints": 123,
      "cardShortDesc": "10% OFF",
      "cardImage": "https://images.gyft.com/merchants/i-1466456891460_667_hd.png",
      "cardIssueDate": "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
      "cardExpiryDate": "Sun May 26 2019 15:43:25 GMT+0530 (India Standard Time)",
      "isRedeemed": false}])
 


})
})



