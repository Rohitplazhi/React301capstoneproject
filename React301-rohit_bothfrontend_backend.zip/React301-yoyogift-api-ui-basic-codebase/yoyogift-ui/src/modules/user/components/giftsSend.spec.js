

import React from "react";
import Adapter from 'enzyme-adapter-react-16';
import {  AutoSizer, InfiniteLoader, Table, Column } from 'react-virtualized';
import { render, mount,shallow } from 'enzyme';
import Paper from '@material-ui/core/Paper';
import { BrowserRouter as Router } from "react-router-dom"
import GiftsSend from "./giftsSend";
import { configure } from 'enzyme';
import { Provider } from "react-redux";
import configureMockStore from "redux-mock-store";
const mockStore = configureMockStore();
const store = mockStore({});
configure({adapter: new Adapter()});

const minProps = {
    data:[],
    classes: '',
  
    user: jest.fn(),
  };
describe('gift send MyComponent', () => {

      let wrapper;

       wrapper = mount(<GiftsSend  {...minProps}/>);


    it('AutoSizer length', () => {
     
        expect(wrapper.find(AutoSizer)).toHaveLength(1);
    });
    it('InfiniteLoader length', () => {
     
        expect(wrapper.find(InfiniteLoader)).toHaveLength(1);
    });
    it('Table length', () => {
  
        expect(wrapper.find(Table)).toHaveLength(1);
        expect(wrapper.find(Table).prop('rowClassName')).toBe('GiftsSend-tableRow-3');
   
    });

    it('Grid properties', () => {
  
      expect(wrapper.find("Grid")).toHaveLength(1);

 
  });
    it('Table properties', () => {
  
        expect(wrapper.find(Table)).toHaveLength(1);
        expect(wrapper.find(Table).prop('rowHeight')).toBe(40);
   
    });
    it('Table properties', () => {
  
        expect(wrapper.find(Table)).toHaveLength(1);
        expect(wrapper.find(Table).prop('headerHeight')).toBe(40);
        
   
    });

    it('Autosizer properties', () => {
  
        expect(wrapper.find(AutoSizer)).toHaveLength(1);
        expect(wrapper.find(AutoSizer).prop('defaultHeight')).toBe(200);

   
    });

    it('paper properties', () => {
  
        expect(wrapper.find(Paper)).toHaveLength(1);
        expect(wrapper.find(Paper).prop('className')).toBe('GiftsSend-root-1');

   
    });
    it('Autosizer properties', () => {
  
      expect(wrapper.find(Table)).toHaveLength(1);
      expect(wrapper.find(Table).prop('ref')).toBe(undefined);

 
  });

    it('children autosizer properties', () => {
  
        jest.mock('react-virtualized', () => {
            const ReactVirtualized = jest.requireActual('react-virtualized');
            return {
              ...ReactVirtualized,
              AutoSizer: ({
                children,
              }) => children({height: 1000, width: 1250}),
            };
          });

   
    });

    
    it('children  table properties', () => {
        const submitButton = wrapper.find('div');
        expect(submitButton).toHaveLength(10);
        jest.mock('react-virtualized', () => {
            const ReactVirtualized = jest.requireActual('react-virtualized');
            return {
              ...ReactVirtualized,
              Table: ({
                children,
              }) => children({rowCount: 1250}),
            };
          });
          });

              


    
});