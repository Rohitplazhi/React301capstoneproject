import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
// import Table from '@material-ui/core/Table';
// import TableBody from '@material-ui/core/TableBody';
// import TableCell from '@material-ui/core/TableCell';
// import TableHead from '@material-ui/core/TableHead';
import { Column, Table, AutoSizer, InfiniteLoader } from 'react-virtualized';
import axiosWrapper from '../../../apis/axiosCreate';
import 'react-virtualized/styles.css';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { Button } from '@material-ui/core';
import {DateFormatter} from '../../common/components/DateFormatter';


const styles = theme => ({
  root: {
    minHeight: '100vh',
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  table: {
    minWidth: 700,
  },
  tableRow:{
    borderBottom: '1px solid #c7c7c7'
 }
});



function GiftsReceived(props) {
  const { classes,data, user } = props;

  const [count,setCount] =React.useState(0);
  const [list,setList] = React.useState('');
  React.useEffect(()=>{
    let email =user && user.email;
    let addProp = '&_start=0&_end=10';
    let url =`http://localhost:10000/giftTransact?receiverEmail=${email}&${addProp}`;
    axiosWrapper.get(url).then((res)=>{

      setList(res.data);

    })
  },[])



  const cellRenderer = (cellData, columnData, columnIndex, dataKey, isScrolling, rowData, rowIndex)=> {
    
    if (cellData && cellData.dataKey === "REDEEM") {
      console.log('cellData', rowIndex)
      return (
        <>
        { cellData.rowData.isRedeemed ? 'Redeemed' :<Button variant="contained" color="primary" onClick={()=>props.redeemCard(cellData.rowData)}>Redeem</Button>}</>
        
      );
    }
    if (cellData && cellData.dataKey === "cardIssueDate") {
 
     return  DateFormatter(cellData.rowData.cardIssueDate)
    }
    if (cellData && cellData.dataKey === "cardExpiryDate") {
      return DateFormatter(cellData.rowData.cardExpiryDate)
    }
  }



   const loadMoreRows =   ({startIndex, stopIndex } )=> {
   console.log('startIndex', startIndex)
   console.log('stopIndex', stopIndex)
   let email =user && user.email;
  
    let url =`http://localhost:10000/giftTransact?receiverEmail=${email}&_start=${startIndex}&_end=${stopIndex}`;
    axiosWrapper.get(url) .then((res)=>{
  
      setList(list.concat(res.data));

    })
   
  }

  return (
    <Paper className={classes.root}>


<AutoSizer defaultHeight={200} style={{ height: "50vh" }}>
{({ height, width }) => (
<InfiniteLoader
isRowLoaded={({ index }) => !!list[index]}
loadMoreRows={loadMoreRows}
rowCount={1500}
>
{({ onRowsRendered, registerChild }) => (
<Table
rowClassName={classes.tableRow}
ref={registerChild}
onRowsRendered={onRowsRendered}
headerHeight={40}
width={1250}
height={height}
rowHeight={40}
rowCount={list.length}
rowGetter={({ index }) => list[index]}
>

    <Column
      label='CARD NAME'
      dataKey='cardName'
      width={width * 0.2}
    />
       <Column
      label='POINTS'
      dataKey='cardPoints'
      width={width * 0.2}
    />
     <Column
      label='RECEIVED FROM'
      dataKey='senderEmail'
      width={width * 0.2}
    />
  <Column
      label='CARD DESC'
      dataKey='cardShortDesc'
      width={width * 0.2}
    />
  <Column
      label='ISSUE DATE'
      dataKey='cardIssueDate'
      cellRenderer={cellRenderer}
      width={width * 0.2}
    />
  <Column
      label='EXPIRY DATE'
      cellRenderer={cellRenderer}
      dataKey='cardExpiryDate'
      width={width * 0.2}
    />
  
  <Column
       cellRenderer={cellRenderer}
      label='REDEEM'
      dataKey = 'REDEEM'
 
      width={width * 0.2}
    />
    
    </Table>
)}
</InfiniteLoader>
)}
</AutoSizer>
    </Paper>
  );
}

GiftsReceived.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(GiftsReceived);