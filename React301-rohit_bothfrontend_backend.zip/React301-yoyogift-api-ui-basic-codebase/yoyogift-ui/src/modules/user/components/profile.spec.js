


import React from "react";
import Adapter from 'enzyme-adapter-react-16';
import Paper from '@material-ui/core/Paper';

import { render, mount, shallow, configure } from 'enzyme';
import { BrowserRouter as Router } from "react-router-dom"
import Profile from "./profile";
import { Provider } from "react-redux";
import configureMockStore from "redux-mock-store";
const mockStore = configureMockStore();
const store = mockStore({});
configure({adapter: new Adapter()});
describe('test MyComponent', () => {
  let wrapper = mount(<Profile />);
    it('should disable submit button on submit click', () => {
       
        const submitButton = wrapper.find('Grid');
        expect(submitButton.length).toBe(0);
      });
      it('should disable submit button on submit click', () => {
  
        const submitButtonss = wrapper.find('label');
        expect(submitButtonss).toHaveLength(0);
   
      });
});