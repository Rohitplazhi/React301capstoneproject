import React from "react";
import Adapter from 'enzyme-adapter-react-16';


import { render, mount } from 'enzyme';
import { BrowserRouter as Router } from "react-router-dom"
import Landing from "./Landing";
import { configure } from 'enzyme';
import {MemoryRouter} from 'react-router-dom';
import { Provider } from "react-redux";
import configureMockStore from "redux-mock-store";
const mockStore = configureMockStore();
const store = mockStore({});
configure({adapter: new Adapter()});
describe("About component Suite landing", ()=> {
  const mockCallBack = jest.fn();
  const component = mount(<MemoryRouter><Landing  onClick={mockCallBack}  /></MemoryRouter>);
    it('should have an image field', () => {
     
      const submitButton = component.find('p');
      expect(submitButton).toHaveLength(7 || undefined);
      }); 

      it('should have an image field', () => {
      
        const submitButton = component.find('p');
        expect(submitButton).toHaveLength(7 || undefined);
        });
     

})