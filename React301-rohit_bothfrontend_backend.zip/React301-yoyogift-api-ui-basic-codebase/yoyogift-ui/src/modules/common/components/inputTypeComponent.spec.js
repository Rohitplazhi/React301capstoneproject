import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, configure, mount } from "enzyme";
import InputTypeComponent from "./inputTypeComponent";

configure({ adapter: new Adapter() });

describe("MySnackBar", () => {
  let component = mount(<InputTypeComponent />);

 it("should render div", () => {
  let wraper = component.find('div');
  expect(wraper.length).toBe(2);

});
it("should render div", () => {
  let wraper = component.find('input');
  expect(wraper.length).toBe(1);

});

});

