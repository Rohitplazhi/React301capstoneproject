import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, configure } from "enzyme";
import ErrorPage from "./ErrorPage";

configure({ adapter: new Adapter() });

describe("Error Page", () => {
 it("Error correctly", () => {
   shallow(<ErrorPage />);
 });
 


});

