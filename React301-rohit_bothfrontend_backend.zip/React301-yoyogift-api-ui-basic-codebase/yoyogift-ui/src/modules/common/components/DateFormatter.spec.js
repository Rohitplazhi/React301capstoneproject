import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, configure,mount } from "enzyme";
import {DateFormatter } from "./DateFormatter";

configure({ adapter: new Adapter() });

describe("MySnackBar", () => {
 it("MySnackBar correctly", () => {
  mount(<DateFormatter />);
 });


});