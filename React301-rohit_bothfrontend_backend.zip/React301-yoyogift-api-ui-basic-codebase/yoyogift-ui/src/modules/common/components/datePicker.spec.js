import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { render, configure ,shallow, mount} from "enzyme";
import  DatePicker  from "./datePicker";

const shallowComponent = (props = {}) => {

   return shallow(<DatePicker {...props} />);
 
 };
configure({ adapter: new Adapter() });

describe("datePicker", () => {
   let component;

   beforeEach(() => {
 
      component = shallowComponent();
 
   });;
 it("MySnackBar correctly", () => {
   shallowComponent();
 });


});

