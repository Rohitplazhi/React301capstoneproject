import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { render, configure ,shallow, mount} from "enzyme";
import { TablePaginationActionsWrapped } from "./TablePaginationActionsWrapped";
import IconButton from "@material-ui/core/IconButton";

const shallowComponent = (props = {}) => {

   return mount(<TablePaginationActionsWrapped {...props} />);
 
 };
configure({ adapter: new Adapter() });

describe("MySnackBar", () => {
   let component;

   beforeEach(() => {
 
      component = shallowComponent();
 
   });;
 it("MySnackBar correctly", () => {
   shallowComponent();
 });

 it("should render div", () => {
  let wraper = component.find('div');
  expect(wraper.length).toBe(1);

});
it("should render div", () => {
  let wraper = component.find(IconButton);
  expect(wraper.length).toBe(4);


});


});

