import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, configure ,mount} from "enzyme";
import {createHistory} from "./history";

configure({ adapter: new Adapter() });

describe("MySnackBar", () => {
 it("MySnackBar correctly", () => {
   mount(<createHistory />);
 });


});

