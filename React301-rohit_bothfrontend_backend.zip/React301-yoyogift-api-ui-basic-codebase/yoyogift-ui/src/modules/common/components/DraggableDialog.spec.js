import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, configure, mount } from "enzyme";
import DraggableDialog from "./DraggableDialog";
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';

configure({ adapter: new Adapter() });
const mockCallBack = jest.fn();
const wrapper = mount(<DraggableDialog  />);
describe("MySnackBar", () => {
 it("MySnackBar correctly", () => {
  wrapper
 });

 it('should show dialogue box', () => {
    expect(wrapper.find(Button).exists()).toBeTruthy();
    expect(wrapper.find(Dialog).prop('open')).toBeFalsy();
    expect(wrapper.find(Button).simulate('click'));
    expect(wrapper.find(Dialog).prop('open')).toBeTruthy();
  });

  it('should show div ', () => {
    expect(wrapper.find('div').length).toEqual(12);

  });
  it('should show p ', () => {
    expect(wrapper.find('p').length).toEqual(1);

  });
  it('should show p ', () => {
    expect(wrapper.find('Button').length).toEqual(0);

  });



});

