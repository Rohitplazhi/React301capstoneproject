import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow,mount, configure } from "enzyme";
import Footer from "./Footer";

configure({ adapter: new Adapter() });

describe("MySnackBar", () => {
  let  wrapper =  mount(<Footer />);
 it("MySnackBar correctly", () => {
  wrapper;
 });

 it("should render submit button", () => {
  let wraper = wrapper.find('p');
  expect(wraper.length).toBe(1);

});

it("should render div", () => {
  let wraper = wrapper.find('div');
  expect(wraper.length).toBe(2);

});
});

