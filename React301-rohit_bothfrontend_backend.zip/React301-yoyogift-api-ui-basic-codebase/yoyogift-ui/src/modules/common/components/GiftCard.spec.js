import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, configure, mount } from "enzyme";
import CardMedia from "@material-ui/core/CardMedia";
import GiftCard from "./GiftCard";
import Card from "@material-ui/core/Card";
import { MemoryRouter } from "react-router-dom";

configure({adapter: new Adapter()});
const minProps = {

    classes: '',

  };
describe("MySnackBar", () => {
  let  wrapper =  mount(<MemoryRouter><GiftCard {...minProps} /></MemoryRouter>);
 it("MySnackBar correctly", () => {
  wrapper;
 });
 it("should render submit button", () => {
    let wraper = wrapper.find('div');
    expect(wraper.length).toBe(7);
  
  });
  it("should render submit button", () => {
    let wraper = wrapper.find('p');
    expect(wraper.length).toBe(1);
  
  });

  

});

