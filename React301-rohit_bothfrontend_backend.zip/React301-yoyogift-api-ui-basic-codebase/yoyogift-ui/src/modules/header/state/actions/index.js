import { LOGIN, LOGOUT } from "./types";
import axiosWrapper from "../../../../apis/axiosCreate";
export const login = object => {

  console.log('object', object)
  return {
    type: LOGIN,
    payload: object
  };
};

export const logout = () => {
  return {
    type: LOGOUT,
    payload: null
  };
};

export const createUser = userDetails => async dispatch => {

  const test = await axiosWrapper.post(`/users`, userDetails);
  return test;
};



export async function createUserDispatch(userDetails) {
  return axiosWrapper.get("/users", userDetails).then(response => response.data);
}



export async function getUsers() {
  return axiosWrapper.get("/users").then(response => response.data);
}