

import axios     from 'axios';
import  MockAdapter from "axios-mock-adapter";
import axiosWrapper from "../../../../apis/axiosCreate";
import { getUsers, createUserDispatch } from "./";

 
// This sets the mock adapter on the default instance
var mock = new MockAdapter(axios);

var mockWrapper = new MockAdapter(axiosWrapper);


describe ("getUsers mock test", () => {
    it ("async test ", async () => {

        mockWrapper.onGet("/users").reply(200, 
             [{ first_name: "Rohit",
             last_name: "K",
             email: "erohitk@gmail.com",
             balance_points: 44,
             id: "S1z6ya-Vq" }]
        );


        const products = await getUsers();
        expect(products).toEqual([{ first_name: "Rohit",
        last_name: "K",
        email: "erohitk@gmail.com",
        balance_points: 44,
        id: "S1z6ya-Vq"}])

    })
})

describe ("getUsers mock test", () => {
    it ("async test ", async () => {

        mockWrapper.onPost("/createUser", {
            "first_name": "Rohit",
          "id": "S1z6ya-Vq",
           "last_name": "K",
           "balance_points": 44,
          "email": "erohitk@gmail.com",
          }).reply(200, 
             [ {
                "first_name": "Rohit",
                "id": "S1z6ya-Vq",
                 "last_name": "K",
                 "balance_points": 44,
                 "email": "erohitk@gmail.com",
             }]
        );


        const products = await createUserDispatch({
            "first_name": "Rohit",
            "id": "S1z6ya-Vq",
             "last_name": "K",
             "balance_points": 44,
             "email": "erohitk@gmail.com",
          });
        expect(products).toEqual([ {
            "first_name": "Rohit",
            "id": "S1z6ya-Vq",
             "last_name": "K",
             "balance_points": 44,
             "email": "erohitk@gmail.com",
          }])

    })
})


