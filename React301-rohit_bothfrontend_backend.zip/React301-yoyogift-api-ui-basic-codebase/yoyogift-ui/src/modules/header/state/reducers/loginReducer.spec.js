import loginReducers from "./loginReducer";
import { LOGIN, LOGOUT } from "../actions/types";


describe ("loginReducers Default Tests", () => {
    
    it ("should be empty list", () => {
        expect(loginReducers (undefined, {type:'NOT THERE'})).toEqual({
            loginStatus: false,detailsObject:{}
        })
    })
    it ("should set login true", () => {
        const action = {type:LOGIN}
        
    
        
        expect(loginReducers ({'loginStatus': true, detailsObject: undefined},action )).toEqual({
            loginStatus: true,detailsObject:undefined
        })
    })
    it ("should set logout false", () => {
        const action = {type:LOGOUT}
        
    
        
        expect(loginReducers ({'loginStatus': false, detailsObject: undefined},action )).toEqual({
            loginStatus: false,detailsObject:{}
        })
    })
 
})