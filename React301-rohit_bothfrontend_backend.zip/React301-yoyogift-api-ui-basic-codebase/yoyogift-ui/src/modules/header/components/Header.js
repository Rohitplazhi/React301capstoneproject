import React, { Component } from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import axiosWrapper from "../../../apis/axiosCreate";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import { GoogleLogin, GoogleLogout } from 'react-google-login';
import { connect } from "react-redux";
import { login, logout, createUser } from "../state/actions";
import { bindActionCreators } from "redux";
import history from "../../common/components/history";
import MySnackBar from "../../common/components/Snackbar";
import Styles from '../../../assets/css/Header.module.css';
import axios from 'axios';

const styles = {
  root: {
    flexGrow: 1,
    flexShrink: 1,
    width: '100%' 
  },
  grow: {
    flexGrow: 1
  },
  toolBar: {
    background: "#32567e"
  }
};

class Header extends Component {
  constructor(props){
    super(props)
    this.state = {
      showErrorSnack: false,
      loginStatus: false
    }
  }

  googleSuccessResponse = async(response)=> {
       this.setState({
        loginStatus: true
      })
    console.log("Successfully logged in", response)
    const id = response && response.profileObj && response.profileObj && response.profileObj.googleId;
    await axiosWrapper.get(`/users/${id}`).then(profile =>{
      window.localStorage.setItem("user", JSON.stringify(profile.data))
      this.props.login(profile.data );
  

    }).catch(async error=>{
      console.log('error', error)
      const user =  await this.props.createUser({...response.profileObj, id: id, balance_points: 5000})
      window.localStorage.setItem("user",JSON.stringify(user.data))
      this.props.login(user.data);
   
    })
  }

googleLoginFailResponse = (response) => {
    console.log("User could not sign in ", response)
}
logoutResponse = ()=>{
  this.setState({
    loginStatus: false
  })
  this.props.logout();
 
  window.localStorage.removeItem("user");
}

componentDidMount(){

if(window.localStorage.getItem("user")){
  this.setState({
    loginStatus: true
  })
  this.props.login(JSON.parse(window.localStorage.getItem("user")));
 
}
}

  render() {
 
    console.log('this.props.userDetails', this.props.userDetails)
    const { showErrorSnack } = this.state
    const { classes } = this.props;
    return (
      <div className={classes.root}>
        {
          showErrorSnack ? 
          <MySnackBar message='Network Error! Please try again' color='red' />
          :
          null
        }
        <AppBar position="static">
          <Toolbar className={classes.toolBar}>
            <Typography variant="h6" color="inherit" className={classes.grow}>
              <Button onClick={this.goTolanding}>
                <span style={{ fontSize: "1.2em", color: "#ffffff" }}>
                  YOYOGift
                </span>
              </Button>
            </Typography>
            {/* {this.props.isLoggedIn ? <Button color="inherit" onClick={this.addUpdateForm}>ADD UPDATE FORM</Button> : null} */}
            {this.props.isLoggedIn ? (
              <Button className={Styles.headerButton} color="inherit" onClick={this.giftsReceived}>
                GIFTS RECEIVED
              </Button>
            ) : null}
            {this.props.isLoggedIn ? (
              <Button className={Styles.headerButton} color="inherit" onClick={this.giftsSend}>
                GIFTS SENT
              </Button>
            ) : null}
            {this.props.isLoggedIn ? (
              <Button className={Styles.headerButton} color="inherit" onClick={this.myProfile}>
                MY PROFILE
              </Button>
            ) : null}
          
            {

this.state.loginStatus && 
<GoogleLogout
clientId="671348139606-906f7lcl8vk6l26hivc1ka0hk2teuvb1.apps.googleusercontent.com"
buttonText="Logout"
onLogoutSuccess={this.logoutResponse}/>
}
     
{

!this.state.loginStatus &&
<GoogleLogin
clientId="67372680030-35h9bcvus8fk5cdr1tau5crlqmdbah81.apps.googleusercontent.com"
buttonText="Login"
onSuccess={this.googleSuccessResponse}
onFailure={this.googleLoginFailResponse}
cookiePolicy={'single_host_origin'}
/>
}
     
          </Toolbar>
        </AppBar>
      </div>
    );
  }

  goTolanding = () => {
    history.push("/");
  };
  myProfile = () => {
    history.push("/Profile");
  };

  giftsSend = () => {
    history.push("/GiftsSend");
  };

  giftsReceived = () => {
    history.push("/GiftsReceived");
  };

  logOut = () => {
    this.props.logout();
    history.push("/");
    window.sessionStorage.removeItem("user");
    window.sessionStorage.removeItem("usertype");
  };

}

Header.propTypes = {
  classes: PropTypes.object.isRequired
};

const mapStateToProps = state => {
  return {
    isLoggedIn: state.login && state.login.loginStatus ? state.login.loginStatus : false,
    userDetails: state.login && state.login.detailsObject ? state.login.detailsObject: {}
  };
};

const mapDispatchToProps = dispatch => {
  return bindActionCreators({ login, logout, createUser }, dispatch);
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(Header));
